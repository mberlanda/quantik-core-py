# Cross-engine benchmark - `2d00e5c8a4f7`

- benchmark family: **native** (per-engine native settings; useful for scaling behavior, not fair head-to-head ranking)
- dataset: `a9aa7c316092be3b9a22c54e4306315e54d38af5bbe931f600c9ccd48213b9aa` - 36 positions {'early_mid': 8, 'endgame': 8, 'late_mid': 12, 'opening': 8}, generation seed 20260711
- engine seeds: `[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29]`
- environment: quantik-core 1.0.0, python 3.12.13, Linux-6.6.122+-x86_64-with-glibc2.35, 2 CPUs
- started: 2026-07-12T07:34:54+0000
- checkpoint status: complete
- checkpoint counts: observations 3276, h2h_records 96

## Exact move agreement

A hit means the selected move is in the complete optimal set proven by the exact solver with no cutoff. Positions without exact references are excluded. For stochastic engines, runs equal positions times seeds.

| Engine | Configuration | Phase | Runs | Optimal selected | Agreement | 95% CI |
| --- | --- | --- | --- | --- | --- | --- |
| beam | `beam(w=16,d=12)` | early_mid | 60 | 33 | 0.550 | [0.425, 0.669] |
| beam | `beam(w=16,d=12)` | endgame | 240 | 240 | 1.000 | [0.984, 1.000] |
| beam | `beam(w=16,d=12)` | late_mid | 360 | 298 | 0.828 | [0.785, 0.863] |
| mcts | `mcts(it=1000,d=16,c=1.414)` | early_mid | 60 | 30 | 0.500 | [0.377, 0.623] |
| mcts | `mcts(it=1000,d=16,c=1.414)` | endgame | 240 | 210 | 0.875 | [0.827, 0.911] |
| mcts | `mcts(it=1000,d=16,c=1.414)` | late_mid | 360 | 240 | 0.667 | [0.616, 0.713] |
| minimax | `minimax(d=16,t=1.0)` | early_mid | 2 | 2 | 1.000 | [0.342, 1.000] |
| minimax | `minimax(d=16,t=1.0)` | endgame | 8 | 8 | 1.000 | [0.676, 1.000] |
| minimax | `minimax(d=16,t=1.0)` | late_mid | 12 | 12 | 1.000 | [0.757, 1.000] |
| random | `random` | early_mid | 60 | 9 | 0.150 | [0.081, 0.261] |
| random | `random` | endgame | 240 | 210 | 0.875 | [0.827, 0.911] |
| random | `random` | late_mid | 360 | 74 | 0.206 | [0.167, 0.250] |

## Computational cost

Measured effective work per move, not just configured limits.

| Engine | Configuration | Moves | Median time (s) | p95 time (s) | Median nodes | Peak memory (bytes) |
| --- | --- | --- | --- | --- | --- | --- |
| beam | `beam(w=16,d=12)` | 1080 | 0.4108 | 16.7220 | 144 | - |
| mcts | `mcts(it=1000,d=16,c=1.414)` | 1080 | 1.3555 | 7.0397 | 168 | - |
| minimax | `minimax(d=16,t=1.0)` | 36 | 1.0316 | 1.7313 | 892 | - |
| random | `random` | 1080 | 0.0001 | 0.0004 | - | - |

## Head-to-head (paired, side-balanced)

Each position and seed is played twice, once with each engine as the side to move. Wins are credited to the actual engine/color mapping. Quantik cannot draw, so Draws is structurally 0.

| Engine A | Engine B | Paired positions | Games | A wins | B wins | Draws | A win rate (95% CI) | A wins as mover | B wins as mover |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| minimax | mcts | 8 | 16 | 10 | 6 | 0 | 0.625 [0.386, 0.815] | 8 | 6 |
| minimax | beam | 8 | 16 | 9 | 7 | 0 | 0.562 [0.332, 0.769] | 7 | 6 |
| minimax | random | 8 | 16 | 14 | 2 | 0 | 0.875 [0.640, 0.965] | 8 | 2 |
| mcts | beam | 8 | 16 | 7 | 9 | 0 | 0.438 [0.231, 0.668] | 6 | 7 |
| mcts | random | 8 | 16 | 13 | 3 | 0 | 0.812 [0.570, 0.934] | 8 | 3 |
| beam | random | 8 | 16 | 13 | 3 | 0 | 0.812 [0.570, 0.934] | 8 | 3 |

### Head-to-head by phase

| Engine A | Engine B | Phase | Games | A wins | B wins |
| --- | --- | --- | --- | --- | --- |
| minimax | mcts | early_mid | 4 | 2 | 2 |
| minimax | mcts | endgame | 4 | 2 | 2 |
| minimax | mcts | late_mid | 4 | 3 | 1 |
| minimax | mcts | opening | 4 | 3 | 1 |
| minimax | beam | early_mid | 4 | 2 | 2 |
| minimax | beam | endgame | 4 | 2 | 2 |
| minimax | beam | late_mid | 4 | 2 | 2 |
| minimax | beam | opening | 4 | 3 | 1 |
| minimax | random | early_mid | 4 | 4 | 0 |
| minimax | random | endgame | 4 | 2 | 2 |
| minimax | random | late_mid | 4 | 4 | 0 |
| minimax | random | opening | 4 | 4 | 0 |
| mcts | beam | early_mid | 4 | 2 | 2 |
| mcts | beam | endgame | 4 | 2 | 2 |
| mcts | beam | late_mid | 4 | 1 | 3 |
| mcts | beam | opening | 4 | 2 | 2 |
| mcts | random | early_mid | 4 | 3 | 1 |
| mcts | random | endgame | 4 | 2 | 2 |
| mcts | random | late_mid | 4 | 4 | 0 |
| mcts | random | opening | 4 | 4 | 0 |
| beam | random | early_mid | 4 | 3 | 1 |
| beam | random | endgame | 4 | 2 | 2 |
| beam | random | late_mid | 4 | 4 | 0 |
| beam | random | opening | 4 | 4 | 0 |

## Stability across seeds

Move consistency is the average fraction of seeds choosing the modal move per position. Agreement mean and std are computed per seed first, then aggregated.

| Engine | Configuration | Seeds | Move consistency | Agreement mean | Agreement std |
| --- | --- | --- | --- | --- | --- |
| beam | `beam(w=16,d=12)` | 30 | 0.680 | 0.865 | 0.022 |
| mcts | `mcts(it=1000,d=16,c=1.414)` | 30 | 0.726 | 0.727 | 0.049 |
| minimax | `minimax(d=16,t=1.0)` | 1 | 1.000 | 1.000 | 0.000 |
| random | `random` | 30 | 0.268 | 0.444 | 0.057 |

## Interpretation guardrails

- Minimax buys adversarial certainty when the remaining tree is small enough; MCTS buys empirical confidence through repeated sampling; beam search buys bounded, selectively deep exploration.
- No engine is universally superior unless the evidence spans multiple phases, equivalent budgets, repeated seeds, and statistically meaningful samples.
- Beam search honors its time limit only between depth levels; compare measured times above, never configured caps.
- Algorithm-native tables explain scaling; only fixed-resource tables support fair engine-vs-engine claims.
