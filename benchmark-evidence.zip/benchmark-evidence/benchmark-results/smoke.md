# Cross-engine benchmark - `175b0fc88596`

- benchmark family: **fixed** (same wall-clock budget per move; fair practical-latency comparison)
- dataset: `a9aa7c316092be3b9a22c54e4306315e54d38af5bbe931f600c9ccd48213b9aa` - 36 positions {'early_mid': 8, 'endgame': 8, 'late_mid': 12, 'opening': 8}, generation seed 20260711
- engine seeds: `[0, 1, 2]`
- environment: quantik-core 1.0.0, python 3.14.5, macOS-26.5.1-arm64-arm-64bit-Mach-O, 8 CPUs
- started: 2026-07-11T22:11:51+0200

## Exact move agreement

A hit means the selected move is in the complete optimal set proven by the exact solver with no cutoff. Positions without exact references are excluded. For stochastic engines, runs equal positions times seeds.

| Engine | Configuration | Phase | Runs | Optimal selected | Agreement | 95% CI |
| --- | --- | --- | --- | --- | --- | --- |
| beam | `beam(w=64,d=16,t=0.25)` | early_mid | 6 | 4 | 0.667 | [0.300, 0.903] |
| beam | `beam(w=64,d=16,t=0.25)` | endgame | 24 | 24 | 1.000 | [0.862, 1.000] |
| beam | `beam(w=64,d=16,t=0.25)` | late_mid | 36 | 29 | 0.806 | [0.650, 0.902] |
| mcts | `mcts(it=10000000,d=16,c=1.414,t=0.25)` | early_mid | 6 | 3 | 0.500 | [0.188, 0.812] |
| mcts | `mcts(it=10000000,d=16,c=1.414,t=0.25)` | endgame | 24 | 21 | 0.875 | [0.690, 0.957] |
| mcts | `mcts(it=10000000,d=16,c=1.414,t=0.25)` | late_mid | 36 | 30 | 0.833 | [0.681, 0.921] |
| minimax | `minimax(d=16,t=0.25)` | early_mid | 2 | 2 | 1.000 | [0.342, 1.000] |
| minimax | `minimax(d=16,t=0.25)` | endgame | 8 | 8 | 1.000 | [0.676, 1.000] |
| minimax | `minimax(d=16,t=0.25)` | late_mid | 12 | 12 | 1.000 | [0.757, 1.000] |
| random | `random` | early_mid | 6 | 1 | 0.167 | [0.030, 0.564] |
| random | `random` | endgame | 24 | 21 | 0.875 | [0.690, 0.957] |
| random | `random` | late_mid | 36 | 12 | 0.333 | [0.202, 0.497] |

## Computational cost

Measured effective work per move, not just configured limits.

| Engine | Configuration | Moves | Median time (s) | p95 time (s) | Median nodes | Peak memory (bytes) |
| --- | --- | --- | --- | --- | --- | --- |
| beam | `beam(w=64,d=16,t=0.25)` | 108 | 0.2697 | 3.3201 | 92 | - |
| mcts | `mcts(it=10000000,d=16,c=1.414,t=0.25)` | 108 | 0.2529 | 0.2591 | 48 | - |
| minimax | `minimax(d=16,t=0.25)` | 36 | 0.2828 | 0.7806 | 530 | - |
| random | `random` | 108 | 0.0001 | 0.0003 | - | - |

## Head-to-head (paired, side-balanced)

Each position and seed is played twice, once with each engine as the side to move. Wins are credited to the actual engine/color mapping. Quantik cannot draw, so Draws is structurally 0.

| Engine A | Engine B | Paired positions | Games | A wins | B wins | Draws | A win rate (95% CI) | A wins as mover | B wins as mover |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| minimax | mcts | 4 | 8 | 7 | 1 | 0 | 0.875 [0.529, 0.978] | 4 | 1 |
| minimax | beam | 4 | 8 | 6 | 2 | 0 | 0.750 [0.409, 0.929] | 4 | 2 |
| minimax | random | 4 | 8 | 7 | 1 | 0 | 0.875 [0.529, 0.978] | 4 | 1 |
| mcts | beam | 4 | 8 | 2 | 6 | 0 | 0.250 [0.071, 0.591] | 2 | 4 |
| mcts | random | 4 | 8 | 7 | 1 | 0 | 0.875 [0.529, 0.978] | 4 | 1 |
| beam | random | 4 | 8 | 6 | 2 | 0 | 0.750 [0.409, 0.929] | 4 | 2 |

### Head-to-head by phase

| Engine A | Engine B | Phase | Games | A wins | B wins |
| --- | --- | --- | --- | --- | --- |
| minimax | mcts | early_mid | 2 | 2 | 0 |
| minimax | mcts | endgame | 2 | 1 | 1 |
| minimax | mcts | late_mid | 2 | 2 | 0 |
| minimax | mcts | opening | 2 | 2 | 0 |
| minimax | beam | early_mid | 2 | 2 | 0 |
| minimax | beam | endgame | 2 | 1 | 1 |
| minimax | beam | late_mid | 2 | 1 | 1 |
| minimax | beam | opening | 2 | 2 | 0 |
| minimax | random | early_mid | 2 | 2 | 0 |
| minimax | random | endgame | 2 | 1 | 1 |
| minimax | random | late_mid | 2 | 2 | 0 |
| minimax | random | opening | 2 | 2 | 0 |
| mcts | beam | early_mid | 2 | 1 | 1 |
| mcts | beam | endgame | 2 | 1 | 1 |
| mcts | beam | late_mid | 2 | 0 | 2 |
| mcts | beam | opening | 2 | 0 | 2 |
| mcts | random | early_mid | 2 | 2 | 0 |
| mcts | random | endgame | 2 | 1 | 1 |
| mcts | random | late_mid | 2 | 2 | 0 |
| mcts | random | opening | 2 | 2 | 0 |
| beam | random | early_mid | 2 | 1 | 1 |
| beam | random | endgame | 2 | 1 | 1 |
| beam | random | late_mid | 2 | 2 | 0 |
| beam | random | opening | 2 | 2 | 0 |

## Stability across seeds

Move consistency is the average fraction of seeds choosing the modal move per position. Agreement mean and std are computed per seed first, then aggregated.

| Engine | Configuration | Seeds | Move consistency | Agreement mean | Agreement std |
| --- | --- | --- | --- | --- | --- |
| beam | `beam(w=64,d=16,t=0.25)` | 3 | 0.787 | 0.864 | 0.045 |
| mcts | `mcts(it=10000000,d=16,c=1.414,t=0.25)` | 3 | 0.806 | 0.818 | 0.000 |
| minimax | `minimax(d=16,t=0.25)` | 1 | 1.000 | 1.000 | 0.000 |
| random | `random` | 3 | 0.444 | 0.515 | 0.069 |

## Interpretation guardrails

- Minimax buys adversarial certainty when the remaining tree is small enough; MCTS buys empirical confidence through repeated sampling; beam search buys bounded, selectively deep exploration.
- No engine is universally superior unless the evidence spans multiple phases, equivalent budgets, repeated seeds, and statistically meaningful samples.
- Beam search honors its time limit only between depth levels; compare measured times above, never configured caps.
- Algorithm-native tables explain scaling; only fixed-resource tables support fair engine-vs-engine claims.
