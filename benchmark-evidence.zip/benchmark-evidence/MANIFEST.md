# Benchmark Evidence Archive

Archive: `benchmark-evidence.zip`

Branch commit: `eb1705a`

Generated on: 2026-07-13

## Contents

### `benchmark-results/`

Completed benchmark outputs and execution checkpoints from `benchmarks/results/`.

- `smoke.json` and `smoke.md`: first smoke run.
- `native-seeds30-agreement.json`: native-family agreement/stability observations.
- `native-seeds30-agreement.h2h.json` and `.md`: initial H2H bundle/report.
- `native-seeds30-h2h16x5.json` and `.md`: expanded 16-position x 5-seed H2H bundle/report.
- `native-seeds30-agreement.ckpt/`: checkpoint JSONL execution rows for the agreement/H2H smoke run.
- `native-seeds30-h2h16x5.ckpt/`: checkpoint JSONL execution rows for the expanded H2H run.

The expanded native H2H run contains:

```text
observations: 3276
h2h games: 960
h2h positions: 16
h2h seeds: 5
engine pairs: 6
games per engine pair: 160
```

The command shape for the expanded run was:

```bash
.venv/bin/python examples/cross_engine_benchmark.py run \
  --dataset benchmarks/positions-v1.json \
  --family native \
  --seeds 30 \
  --minimax-depth 16 \
  --minimax-time 1.0 \
  --mcts-iterations 1000 \
  --beam-width 16 \
  --beam-depth 12 \
  --h2h-positions 16 \
  --h2h-seeds 5 \
  --workers 8 \
  --checkpoint-dir benchmarks/results/native-seeds30-h2h16x5.ckpt \
  --resume \
  --skip-agreement \
  --output benchmarks/results/native-seeds30-h2h16x5.json
```

### `depth4-canonical/`

Reusable depth-4 canonical input datasets:

- `sample-1000.json`: combined deterministic 1,000-position sample.
- `sample-1000-part-01.json` through `sample-1000-part-04.json`: four 250-position shards for parallel cloud runs.

These inputs support the planned exploratory depth4 canonical run:

```text
observations: 16000
h2h games: 384
h2h positions: 16
h2h seeds: 2
engine pairs: 6
games per engine pair: 64
```

No completed depth4 canonical result bundle was present in this worktree when this archive was produced.

### `docs/`

- `benchmarks-README.md`: benchmark utility usage, formulas, checkpointing, sharding, merge guidance, and depth4 canonical notes.

## Notes

- `benchmarks/results/` is intentionally gitignored in the repository; this archive is the compact commit-friendly container for preserving the exploratory evidence.
- `.DS_Store` and duplicate operating-system metadata files are excluded.
- The archive is evidence, not a supported public data API.
